To use this module, you need to:

#. Go to Project -> Configuration -> Stages and click on a stage
#. Select the state you would like to associate that stage with from the dropdown "State" menu
#. Save your changes
#. Go to Project -> Dashboard and click on a project
#. Click on task in the stage you just edited
#. Under the "Extra Info" tab, you can see the "State" field for that task
