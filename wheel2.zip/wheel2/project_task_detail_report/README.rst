==========================
Project Task Detail Report
==========================

* Print details of Task with project details and time sheet of the task with hours summary.

Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

